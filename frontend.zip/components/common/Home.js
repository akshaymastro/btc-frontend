import React from "react";
const Home = () => {
  return <h1>Guess the BTC Rate</h1>;
};

export default Home;
